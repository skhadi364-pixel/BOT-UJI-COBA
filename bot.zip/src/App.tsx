import { useState, useEffect, useRef } from 'react';
import { BotControlPanel, BotConfig } from './components/BotControlPanel';
import { TerminalViewer } from './components/TerminalViewer';
import { TradingChart } from './components/TradingChart';
import { BotState, ChartDataPoint } from './types';
import { fetchHistoricalData } from './lib/marketApi';
import { calculateEMA } from './lib/technicalAnalysis';
import { format } from 'date-fns';
import { Settings, Play, Zap, UserSquare2, X } from 'lucide-react';
import { cn } from './lib/utils';

export default function App() {
  const [botState, setBotState] = useState<BotState>({
    status: 'idle',
    logs: ['> [INFO] CORE_ENGINE: Initializing MT5 connection...'],
    symbol: '-',
    price: 0,
    trend: 'WAITING...',
    recommendation: '-',
    balance: 0,
    initialBalance: 0,
    targetProfit: 0,
    currency: 'USD',
    account: '-',
    server: '-',
  });

  const [botConfig, setBotConfig] = useState<BotConfig>({
    account: '12345678',
    password: '',
    server: 'Exness-MT5-Real',
    symbol: 'BTCUSDT',
    timeframe: '15',
    initialCapital: '250000',
    targetProfit: '50000',
    tradingMode: 'AUTO',
  });

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const [chartData, setChartData] = useState<ChartDataPoint[]>([]);

  const appendLog = (message: string) => {
    setBotState(prev => ({ ...prev, logs: [...prev.logs, message] }));
  };

  const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  const runBotEngine = async () => {
    // Determine the current balance, initially using initialCapital
    const currentBalance = botState.balance > 0 ? botState.balance : (Number(botConfig.initialCapital) || 0);
    // Enforce target profit boundaries (350.000 to 1.000.000)
    let rawTarget = Number(botConfig.targetProfit) || 0;
    if (rawTarget < 350000) rawTarget = 350000;
    if (rawTarget > 1000000) rawTarget = 1000000;
    const targetProfitAmount = rawTarget;

    setBotState({
      ...botState,
      status: 'connecting',
      logs: botState.status === 'stopped' || botState.status === 'idle' ? ['=== Memulai Sistem Autotrading Standalone ==='] : [...botState.logs, '=== Memulai Siklus Autotrading Baru ==='],
      symbol: botConfig.symbol,
      price: 0,
      trend: 'WAITING...',
      recommendation: '-',
      balance: currentBalance,
      initialBalance: currentBalance,
      targetProfit: targetProfitAmount,
      currency: 'IDR',
      account: botConfig.account,
      server: botConfig.server,
    });
    setChartData([]);

    try {
      if (botState.status === 'idle' || botState.status === 'stopped') {
        await delay(600);
        appendLog('Menginisialisasi MT5 secara background (tanpa GUI)...');
        await delay(800);
        appendLog(`Login ke server ${botConfig.server} dengan akun: ${botConfig.account}...`);
        await delay(1200);
        
        // Simulasi validasi kredensial MT5 Broker
        if (!botConfig.account || !botConfig.password || !botConfig.server || botConfig.password !== 'admin123') {
          appendLog('<strong class="text-rose-500 font-bold">[ERROR] AKSES DITOLAK: Account ID, Password, atau Server tidak valid.</strong>');
          appendLog('<span class="text-gray-500">Petunjuk: Gunakan password "admin123" untuk simulasi berhasil.</span>');
          setBotState(prev => ({ ...prev, status: 'stopped' }));
          return;
        }

        appendLog('Berhasil Terhubung!');
        appendLog(`Saldo Terdeteksi: Rp ${currentBalance.toLocaleString('id-ID')} - Target Profit: Rp ${targetProfitAmount.toLocaleString('id-ID')}`);
        appendLog('==============================================');
      }

      setBotState(prev => ({ ...prev, status: 'downloading' }));
      appendLog(`Mengunduh 1000 candle terakhir untuk ${botConfig.symbol}...`);
      await delay(500);

      const candles = await fetchHistoricalData(botConfig.symbol, botConfig.timeframe + 'm');
      appendLog(`Berhasil mengambil ${candles.length} baris data market.`);
      appendLog('>> mt5.shutdown() dieksekusi. Memutus stream jaringan demi efisiensi.');

      setBotState(prev => ({ ...prev, status: 'analyzing' }));
      appendLog('==============================================');
      appendLog('Memproses DataFrame (Pandas/Engine C++ emulation)...');
      await delay(400);

      const closePrices = candles.map(c => c.close);
      appendLog('Menghitung EMA_Fast (Span: 50)...');
      const emaFast = calculateEMA(closePrices, 50);
      
      await delay(300);
      appendLog('Menghitung EMA_Slow (Span: 200)...');
      const emaSlow = calculateEMA(closePrices, 200);

      const processedData: ChartDataPoint[] = candles.map((c, i) => ({
        time: format(c.time, 'HH:mm (dd/MM)'),
        close: c.close,
        emaFast: emaFast[i],
        emaSlow: emaSlow[i]
      }));
      setChartData(processedData);

      // 4. KONDISI & KEPUTUSAN
      await delay(600);
      const currentPrice = closePrices[closePrices.length - 1];
      const currentEmaFast = emaFast[emaFast.length - 1] as number;
      const currentEmaSlow = emaSlow[emaSlow.length - 1] as number;

      let trend: BotState['trend'] = 'SIDEWAYS (KONSOLIDASI)';
      let rec: BotState['recommendation'] = 'WAIT / JANGAN MASUK';

      if (currentPrice > currentEmaFast && currentEmaFast > currentEmaSlow) {
        trend = 'BULLISH (UPTREND)';
        rec = 'BUY';
      } else if (currentPrice < currentEmaFast && currentEmaFast < currentEmaSlow) {
        trend = 'BEARISH (DOWNTREND)';
        rec = 'SELL';
      }

      let simulatedProfit = 0;
      if (botConfig.tradingMode === 'AUTO' && (rec === 'BUY' || rec === 'SELL')) {
        simulatedProfit = Math.floor(Math.random() * 50000) + 15000;
        appendLog(`🤖 <strong class="text-emerald-400">[AUTO TRADE] Eksekusi ${rec} berhasil. Profit: +Rp ${simulatedProfit.toLocaleString('id-ID')}</strong>`);
      }
      const newBalance = currentBalance + simulatedProfit;

      let isAutoStopped = false;
      if (targetProfitAmount > 0 && newBalance >= targetProfitAmount) {
         isAutoStopped = true;
         trend = 'SIDEWAYS (KONSOLIDASI)';
         rec = 'WAIT / JANGAN MASUK';
         appendLog('');
         appendLog('🎯 <strong class="text-amber-400">[AUTO STOP] Target profit tercapai/terlampaui. Trading dihentikan.</strong>');
         appendLog('<span class="text-gray-500">Sistem akan kembali ke layar utama secara otomatis dalam 5 detik...</span>');
         setTimeout(() => {
           setBotState({
              status: 'idle',
              logs: ['> [INFO] CORE_ENGINE: Initializing MT5 connection...'],
              symbol: '-',
              price: 0,
              trend: 'WAITING...',
              recommendation: '-',
              balance: 0,
              initialBalance: 0,
              targetProfit: 0,
              currency: 'USD',
              account: '-',
              server: '-',
            });
            setChartData([]);
         }, 5000);
      }

      if (botConfig.tradingMode === 'MANUAL') {
         appendLog('');
         appendLog('👤 <strong class="text-blue-400">[MANUAL MODE] User must execute the trade manually. System waiting.</strong>');
      }

      setBotState(prev => ({
        ...prev,
        status: isAutoStopped ? 'stopped' : 'ready',
        price: currentPrice,
        trend,
        recommendation: rec,
        balance: newBalance
      }));

      appendLog('\n=== HASIL ANALISA AGENT ===');
      appendLog(`Pasar / Simbol   : ${botConfig.symbol}`);
      appendLog(`Kondisi Tren     : ${trend}`);
      appendLog(`Harga Real-Time  : ${currentPrice.toLocaleString()}`);
      appendLog(`Rekomendasi Bot  : ${rec}`);
      appendLog(`Saldo Terkini    : Rp ${newBalance.toLocaleString('id-ID')}`);
      appendLog('=============================');
      appendLog(`Siklus selesai dalam ${(Math.random() * 0.05 + 0.01).toFixed(3)} ms.`);

    } catch (err: any) {
      appendLog(`\n[ERROR] ${err.message}`);
      setBotState(prev => ({ ...prev, status: 'error' }));
    }
  };

  const getEmaFast = () => {
    if (chartData.length === 0) return '---';
    const val = chartData[chartData.length - 1].emaFast;
    return val ? val.toLocaleString('en-US', { maximumFractionDigits: 2 }) : '---';
  };

  const getEmaSlow = () => {
    if (chartData.length === 0) return '---';
    const val = chartData[chartData.length - 1].emaSlow;
    return val ? val.toLocaleString('en-US', { maximumFractionDigits: 2 }) : '---';
  };

  const isEngineRunning = ['connecting', 'downloading', 'analyzing'].includes(botState.status);

  // Auto-run effect for AUTO mode
  const latestConfig = useRef(botConfig);
  latestConfig.current = botConfig;
  
  useEffect(() => {
    let timeoutId: any;
    if (botConfig.tradingMode === 'AUTO' && (botState.status === 'ready' || botState.status === 'idle') && !isEngineRunning) {
      // Start immediately if idle, or after delay if ready
      const delayTime = botState.status === 'idle' ? 500 : 3000;
      timeoutId = setTimeout(() => {
        runBotEngine();
      }, delayTime);
    }
    return () => clearTimeout(timeoutId);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [botConfig.tradingMode, botState.status, isEngineRunning]);

  const handleReset = () => {
    setBotState({
      status: 'idle',
      logs: ['> [INFO] CORE_ENGINE: Initializing MT5 connection...'],
      symbol: '-',
      price: 0,
      trend: 'WAITING...',
      recommendation: '-',
      balance: 0,
      initialBalance: 0,
      targetProfit: 0,
      currency: 'USD',
      account: '-',
      server: '-',
    });
    setChartData([]);
  };

  return (
    <div className="h-screen flex flex-col bg-[#050505] overflow-hidden">
      <header className="flex items-center justify-between px-6 py-4 lg:px-8 lg:py-5 border-b border-white/[0.05] bg-[#185c0a] shrink-0">
        <div className="flex items-center space-x-4">
          <div className="relative flex w-3 h-3">
             <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-20"></span>
             <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]"></span>
          </div>
          <h1 className="text-lg lg:text-xl font-black tracking-tight text-white flex items-baseline">MT5<span className="text-emerald-500 mx-1">CORE</span>ENGINE <span className="hidden sm:inline-block text-[10px] font-bold text-gray-600 ml-3 uppercase tracking-widest font-mono">v3.0.4 - STANDALONE</span></h1>
        </div>
        <div className="flex items-center gap-8">
          <div className="hidden md:flex space-x-8 text-[10px] uppercase tracking-widest mr-4 font-mono">
            <div className="flex flex-col">
              <span className="text-gray-600 font-bold mb-1">Mode</span>
              <span className="text-white flex items-center shrink-0">
                {botConfig.tradingMode === 'AUTO' ? <Zap className="w-3.5 h-3.5 text-emerald-400 mr-2" /> : <UserSquare2 className="w-3.5 h-3.5 text-blue-400 mr-2" />}
                {botConfig.tradingMode === 'AUTO' ? 'System Auto' : 'Manual User'}
              </span>
            </div>
            <div className="flex flex-col border-l border-white/[0.05] pl-8">
              <span className="text-gray-600 font-bold mb-1">Broker Server</span>
              <span className="text-white">{botState.server !== '-' ? botState.server : botConfig.server}</span>
            </div>
            <div className="flex flex-col border-l border-white/[0.05] pl-8">
              <span className="text-gray-600 font-bold mb-1">Account ID</span>
              <span className="text-white">{botState.account !== '-' ? botState.account : botConfig.account}</span>
            </div>
            <div className="flex flex-col border-l border-white/[0.05] pl-8">
              <span className="text-gray-600 font-bold mb-1">Current Balance</span>
              <span className="text-emerald-400 font-black font-sans text-sm tracking-tight pt-0.5">
                {botState.balance > 0 ? (botState.currency === 'IDR' ? 'Rp ' : '$') + botState.balance.toLocaleString('id-ID') : '---'}
              </span>
            </div>
            <div className="flex flex-col border-l border-white/[0.05] pl-8">
              <span className="text-emerald-900 font-bold mb-1 text-emerald-600">Target Profit</span>
              <span className="text-white font-bold font-sans">
                {botState.targetProfit > 0 ? (botState.currency === 'IDR' ? 'Rp ' : '$') + botState.targetProfit.toLocaleString('id-ID') : '---'}
              </span>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button 
              onClick={handleReset}
              className="p-3 flex items-center justify-center rounded-2xl border border-rose-500/20 bg-rose-500/10 hover:bg-rose-500/20 transition-colors text-rose-400 hover:text-rose-300 relative overflow-hidden group"
              title="Close Trading and Reset"
            >
              <div className="absolute inset-0 bg-white/[0.05] opacity-0 group-hover:opacity-100 transition-opacity" style={{ backgroundColor: '#ee0a0a' }}></div>
              <X className="w-5 h-5 relative z-10 group-hover:rotate-90 transition-transform duration-300" />
            </button>
            <button 
              onClick={() => setIsSettingsOpen(true)}
              className="p-3 flex items-center justify-center rounded-2xl border border-white/[0.05] bg-[#0A0A0A] hover:bg-gray-800 transition-colors text-gray-400 hover:text-white relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-white/[0.05] opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <Settings className="w-5 h-5 relative z-10" />
            </button>
          </div>
        </div>
      </header>

      <main className="flex-grow grid grid-cols-1 lg:grid-cols-12 gap-6 px-6 py-4 lg:px-8 lg:py-6 bg-[#30c329] overflow-auto scrollbar-hide">
        
        {/* Left Column - Chart & Metrics */}
        <section className="lg:col-span-8 bg-[#0319bc] w-[327px] h-[216px] p-6 lg:p-8 flex flex-col rounded-3xl border border-white/[0.05] relative shadow-2xl overflow-hidden">
          <div className="absolute top-0 right-0 p-32 opacity-[0.03] pointer-events-none">
            <Zap className="w-64 h-64 text-white" />
          </div>
          
          <div className="flex justify-between items-end mb-4 relative z-10">
            <h2 className="text-[10px] font-bold tracking-widest uppercase text-[#fbfafa] font-mono leading-[13px]">3000 Candle Trend Visualization</h2>
            <div className="flex space-x-6 text-[10px] font-bold font-mono text-[#f8f8f8]">
              <span className="flex items-center text-[#fcfdff]"><div className="w-2 h-2 rounded-full bg-emerald-500 mr-2 shadow-[0_0_8px_#10b981]"></div> PRICE</span>
              <span className="flex items-center text-[#fcfcff]"><div className="w-2 h-2 rounded-full bg-blue-500 mr-2 shadow-[0_0_8px_#3b82f6]"></div> EMA 50</span>
              <span className="flex items-center text-[#fcfcff]"><div className="w-2 h-2 rounded-full bg-purple-500 mr-2 shadow-[0_0_8px_#a855f7]"></div> EMA 200</span>
            </div>
          </div>
          
          <div className="flex-grow min-h-[250px] relative z-10">
             <TradingChart data={chartData} symbol={botConfig.symbol} timeframe={botConfig.timeframe} />
          </div>

          <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-6 relative z-10">
            <div style={{ marginLeft: '0px', marginRight: '0px', paddingLeft: '2px', paddingBottom: '2px', paddingTop: '0px', marginTop: '-13px', color: '#fafafc' }} className="border border-white/[0.05] rounded-2xl pr-6 bg-[#0D0D12] shadow-inner relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                <Zap className="w-16 h-16 text-white" />
              </div>
              <span className="block font-bold tracking-widest uppercase font-mono" style={{ fontSize: '10px', marginTop: '-18px', color: '#f4f5f7' }}>Real-Time Price</span>
              <span className="text-3xl font-black tracking-tight text-white mt-2 block font-sans">
                {botState.price > 0 ? botState.price.toLocaleString('en-US') : '---'}
              </span>
            </div>
            <div className="border border-white/[0.05] rounded-2xl p-6 bg-[#0D0D12] shadow-inner">
              <span className="block text-[10px] font-bold tracking-widest text-gray-500 uppercase font-mono">EMA Fast (50)</span>
              <span className="text-3xl font-black tracking-tight text-blue-400 mt-2 block font-sans">{getEmaFast()}</span>
            </div>
            <div className="border border-white/[0.05] rounded-2xl p-6 bg-[#0D0D12] shadow-inner">
              <span className="block text-[10px] font-bold tracking-widest text-gray-500 uppercase font-mono">EMA Slow (200)</span>
              <span className="text-3xl font-black tracking-tight text-purple-400 mt-2 block font-sans">{getEmaSlow()}</span>
            </div>
          </div>
        </section>

        {/* Right Column - Analysis & Config */}
        <section className="lg:col-span-4 bg-[#0A0A0A] flex flex-col rounded-3xl border border-white/[0.05] shadow-2xl relative overflow-hidden">
          <div className="p-6 flex flex-col h-full mt-0 ml-0">
            <h2 className="text-[11px] font-bold tracking-widest uppercase text-[#fefefe] mb-4 font-mono">Analysis Result</h2>
            
            <div className={cn(
              "p-5 rounded-2xl mb-4 relative overflow-hidden border",
              botState.trend.includes('BULLISH') ? 'bg-emerald-500/10 border-emerald-500/20' :
              botState.trend.includes('BEARISH') ? 'bg-rose-500/10 border-rose-500/20' :
              'bg-white/[0.02] border-white/[0.05]'
            )} style={{ backgroundColor: '#24b707' }}>
              <div className="absolute top-0 right-0 -mr-4 -mt-4 w-32 h-32 bg-white/5 rounded-full blur-2xl pointer-events-none"></div>
              <span className={cn(
                "block tracking-widest font-mono uppercase mb-0 p-0 m-0 -mt-[15px] font-bold text-[21px] text-center !text-[#b10000] border-[#fbfbfb]"
              )}>Current Trend</span>
              <span className={cn(
                "text-xl font-black tracking-tight font-sans relative z-10",
                botState.trend.includes('BULLISH') ? 'text-emerald-400 drop-shadow-[0_0_12px_rgba(52,211,153,0.4)]' :
                botState.trend.includes('BEARISH') ? 'text-rose-400 drop-shadow-[0_0_12px_rgba(251,113,133,0.4)]' : 'text-gray-400'
              )}>{botState.trend}</span>
            </div>

            <div className={cn(
              "p-6 flex flex-col items-center justify-center text-center transition-all duration-500 min-h-[160px] rounded-3xl border shadow-xl relative overflow-hidden flex-grow",
              botState.recommendation === 'BUY' ? "bg-emerald-500/10 border-emerald-500/30" :
              botState.recommendation === 'SELL' ? "bg-rose-500/10 border-rose-500/30" :
              "bg-white/[0.02] border-white/[0.05]"
            )} style={{ backgroundColor: '#e6dede' }}>
              {botState.recommendation === 'BUY' && <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(16,185,129,0.15),transparent_70%)]"></div>}
              {botState.recommendation === 'SELL' && <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(244,63,94,0.15),transparent_70%)]"></div>}
              
              <span className="block uppercase font-bold tracking-widest mb-3 font-mono relative z-10" style={{ color: '#010000', fontSize: '21px' }}>Signal Action</span>
              <span className={cn(
                "text-[50px] lg:text-[60px] leading-none font-black mb-2 tracking-tighter relative z-10",
                botState.recommendation === 'BUY' ? "text-emerald-400 drop-shadow-[0_0_20px_rgba(52,211,153,0.6)]" :
                botState.recommendation === 'SELL' ? "text-rose-400 drop-shadow-[0_0_20px_rgba(251,113,133,0.6)]" : "text-gray-600"
              )}>{botState.recommendation}</span>
              <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest opacity-80 font-mono relative z-10">
                Confidence Index: {botState.recommendation !== '-' ? '94.2%' : '---'}
              </span>
            </div>
            
            <div className="mt-4 flex flex-col space-y-3 shrink-0">
               <button 
                 onClick={runBotEngine}
                 disabled={isEngineRunning}
                 className={cn(
                   "w-full py-5 rounded-2xl text-xs font-bold tracking-widest uppercase transition-all flex items-center justify-center space-x-2 border shadow-lg relative overflow-hidden group",
                   isEngineRunning 
                     ? "bg-[#0D0D12] border-white/[0.05] text-gray-500 cursor-not-allowed" 
                     : botState.status === 'stopped' 
                       ? "bg-amber-500/10 border-amber-500/50 hover:bg-amber-500/20 text-amber-500 hover:shadow-[0_0_20px_rgba(245,158,11,0.2)]" 
                       : "bg-emerald-500/10 border-emerald-500/50 hover:bg-emerald-500/20 text-emerald-400 hover:shadow-[0_0_20px_rgba(16,185,129,0.3)]"
                 )}
               >
                 {isEngineRunning ? (
                    <>
                      <span className="relative flex h-3 w-3 mr-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                      </span>
                      Mengeksekusi...
                    </>
                 ) : (
                    <>
                      <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                      <Play className="w-5 h-5 fill-current mr-2 relative z-10" />
                      <span className="relative z-10">{botState.status === 'stopped' ? 'Restart Engine' : 'Execute Bot'}</span>
                    </>
                 )}
               </button>

               <button 
                  onClick={() => setIsSettingsOpen(true)}
                  className="w-full py-4 rounded-xl text-xs font-bold tracking-widest text-gray-400 uppercase bg-[#0D0D12] border border-white/[0.05] hover:border-white/10 hover:text-white transition-colors flex items-center justify-center"
               >
                  <Settings className="w-4 h-4 mr-2" />
                  Configure Settings
               </button>
               
               <div className="w-full pt-6 mt-2 border-t border-white/[0.05]">
                 <h3 className="text-[10px] text-gray-600 uppercase mb-4 font-bold tracking-widest font-mono">Engine Efficiency</h3>
                 <div className="flex justify-between items-center text-xs mb-3">
                   <span className="text-gray-500 font-bold">Data Volume</span>
                   <span className="text-gray-300 font-mono">3,000 Candles</span>
                 </div>
                 <div className="flex justify-between items-center text-xs mb-3">
                   <span className="text-gray-500 font-bold">Processing Latency</span>
                   <span className="text-emerald-400 font-mono">{(Math.random() * 0.05 + 0.01).toFixed(3)}s</span>
                 </div>
                 <div className="flex justify-between items-center text-xs">
                   <span className="text-gray-500 font-bold">Network State</span>
                   <span className="text-blue-400 uppercase font-bold tracking-widest text-[10px] bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">Standalone</span>
                 </div>
               </div>
            </div>
          </div>
        </section>

      </main>

      <footer className="h-[120px] mx-6 lg:-mt-1 lg:mx-8 mb-4 lg:mb-6 rounded-3xl border border-white/[0.05] bg-[#0A0A0A] flex flex-col md:flex-row shrink-0 relative overflow-hidden shadow-2xl z-20">
        <div className="md:w-1/4 border-b md:border-b-0 md:border-r border-white/[0.05] p-5 flex flex-col justify-center bg-[#0D0D12]">
          <span className="text-[10px] text-[#ffffff] uppercase mb-3 font-bold tracking-widest font-mono">System Diagnostics</span>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[#f4f6f9] text-[11px] font-bold">Pandas Kernel</span>
            <div className="flex items-center space-x-2 bg-emerald-500/10 px-2 py-1 rounded text-[10px] border border-emerald-500/20">
              <span className="text-emerald-500 block w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]"></span>
              <span className="text-emerald-400 font-mono">v2.1.0</span>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-[#eff1f8] text-[11px] font-bold">MT5 Python Lib</span>
            <div className="flex items-center space-x-2 bg-emerald-500/10 px-2 py-1 rounded text-[10px] border border-emerald-500/20">
              <span className="text-emerald-500 block w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]"></span>
              <span className="text-emerald-400 font-mono">v5.0.33</span>
            </div>
          </div>
        </div>
        <div className="flex-grow flex flex-col overflow-hidden">
          <TerminalViewer logs={botState.logs} className="h-full" />
        </div>
      </footer>

      <BotControlPanel 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        config={botConfig}
        onChange={setBotConfig}
        onStart={runBotEngine}
        isRunning={isEngineRunning}
      />
    </div>
  );
}
