// Replicates the pandas EWM function: df['close'].ewm(span=X, adjust=False).mean()
export function calculateEMA(prices: number[], span: number): (number | null)[] {
  if (prices.length === 0) return [];
  
  const k = 2 / (span + 1);
  const ema: (number | null)[] = new Array(prices.length).fill(null);
  
  // Seed the first value
  ema[0] = prices[0];
  
  for (let i = 1; i < prices.length; i++) {
    // EWM formula calculation
    ema[i] = (prices[i] * k) + ((ema[i - 1] as number) * (1 - k));
  }
  
  return ema;
}
