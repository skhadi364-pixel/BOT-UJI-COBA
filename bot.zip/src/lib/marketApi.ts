import { Candle } from '../types';

/**
 * Fetch generic market data from public Binance API 
 * Used to simulate the MT5 copy_rates_from_pos function for web previews.
 * Fetches 1000 candles to provide enough history for EMA(200).
 */
export async function fetchHistoricalData(symbol: string, interval: string = '15m'): Promise<Candle[]> {
  // Normalize symbol (e.g. BTCUSD -> BTCUSDT for binance)
  let formattedSymbol = symbol.toUpperCase().replace(/[^A-Z]/g, '');
  if (formattedSymbol === 'BTCUSD') formattedSymbol = 'BTCUSDT';
  
  const res = await fetch(`https://api.binance.com/api/v3/klines?symbol=${formattedSymbol}&interval=${interval}&limit=1000`);
  
  if (!res.ok) {
    throw new Error(`Data fetching failed for ${formattedSymbol}`);
  }
  
  const data = await res.json();
  
  return data.map((d: any) => ({
    time: new Date(d[0]),
    open: parseFloat(d[1]),
    high: parseFloat(d[2]),
    low: parseFloat(d[3]),
    close: parseFloat(d[4]),
    volume: parseFloat(d[5])
  }));
}
