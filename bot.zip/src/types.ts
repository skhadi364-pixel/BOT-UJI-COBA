export interface Candle {
  time: Date;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface ChartDataPoint {
  time: string;
  close: number;
  emaFast: number | null;
  emaSlow: number | null;
}

export type TrendStatus = 'BULLISH (UPTREND)' | 'BEARISH (DOWNTREND)' | 'SIDEWAYS (KONSOLIDASI)' | 'WAITING...';
export type Recommendation = 'BUY' | 'SELL' | 'WAIT / JANGAN MASUK' | '-';

export interface BotState {
  status: 'idle' | 'connecting' | 'downloading' | 'analyzing' | 'ready' | 'error' | 'stopped';
  logs: string[];
  symbol: string;
  price: number;
  trend: TrendStatus;
  recommendation: Recommendation;
  balance: number;
  initialBalance: number;
  targetProfit: number;
  currency: string;
  account: string;
  server: string;
}
