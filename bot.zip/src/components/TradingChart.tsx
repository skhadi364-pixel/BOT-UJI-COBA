import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Line, ComposedChart } from 'recharts';
import { ChartDataPoint } from '../types';

interface TradingChartProps {
  data: ChartDataPoint[];
  symbol?: string;
  timeframe?: string;
}

export function TradingChart({ data, symbol = 'BTCUSD', timeframe = '15' }: TradingChartProps) {
  // We sub-sample for display if data is too large, 
  // but for a web interface 300-1000 points renders fine with Recharts.
  const displayData = data.slice(-150); // Show last 150 candles for visibility

  if (data.length === 0) {
    return (
      <div className="h-full w-full flex items-center justify-center bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgc2hhcGUtcmVuZGVyaW5nPSJjcmlzcEVkZ2VzIj48cmVjdCB3aWR0aD0iMSIgaGVpZ2h0PSI0MCIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjAyKSIvPjxyZWN0IHdpZHRoPSI0MCIgaGVpZ2h0PSIxIiBmaWxsPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDIpIi8+PC9nPjwvc3ZnPg==')] border border-white/[0.05] relative rounded-2xl overflow-hidden shadow-inner bg-[#0D0D12]">
        <span className="font-mono text-[10px] text-gray-500 uppercase tracking-widest bg-[#0A0A0A] px-6 py-3 border border-white/[0.05] rounded-xl shadow-lg">
          Chart Offline - Menunggu Koneksi
        </span>
      </div>
    );
  }

  // Calculate min and max for Y-Axis dynamically to make fluctuations visible
  const minPrice = Math.min(...displayData.map(d => d.close)) * 0.9995;
  const maxPrice = Math.max(...displayData.map(d => d.close)) * 1.0005;

  return (
    <div className="h-full w-full bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgc2hhcGUtcmVuZGVyaW5nPSJjcmlzcEVkZ2VzIj48cmVjdCB3aWR0aD0iMSIgaGVpZ2h0PSI0MCIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjAyKSIvPjxyZWN0IHdpZHRoPSI0MCIgaGVpZ2h0PSIxIiBmaWxsPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDIpIi8+PC9nPjwvc3ZnPg==')] border border-white/[0.05] relative z-0 rounded-2xl overflow-hidden shadow-inner bg-[#0D0D12]/50">
      <div className="absolute inset-x-0 bottom-6 right-6 z-10 text-right pointer-events-none">
        <span className="text-[10px] text-gray-600 bg-[#0A0A0A]/80 px-3 py-1 font-mono rounded-lg border border-white/[0.05] shadow-lg backdrop-blur-sm uppercase">
          [+] SYMBOL: {symbol} | [T] TF: {timeframe}M
        </span>
      </div>
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={displayData} margin={{ top: 20, right: 10, left: 10, bottom: 20 }}>
          <defs>
            <linearGradient id="colorClose" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#10b981" stopOpacity={0.25}/>
              <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
            </linearGradient>
            <linearGradient id="gridGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#fff" stopOpacity={0.02} />
              <stop offset="100%" stopColor="#fff" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="url(#gridGradient)" vertical={false} />
          <XAxis 
            dataKey="time" 
            tick={{ fill: '#4b5563', fontSize: 10, fontFamily: 'JetBrains Mono' }} 
            axisLine={{ stroke: '#ffffff', strokeOpacity: 0.1 }}
            tickLine={{ stroke: '#ffffff', strokeOpacity: 0.1 }}
            tickFormatter={(val) => val.split(' ')[0]}
            minTickGap={30}
          />
          <YAxis 
            domain={[minPrice, maxPrice]} 
            tick={{ fill: '#4b5563', fontSize: 10, fontFamily: 'JetBrains Mono' }} 
            axisLine={false}
            tickLine={false}
            orientation="right"
            tickFormatter={(val) => val.toLocaleString('en-US', { maximumFractionDigits: 2 })}
          />
          <Tooltip 
            contentStyle={{ backgroundColor: '#0D0D12', borderColor: 'rgba(255,255,255,0.05)', borderRadius: '12px', color: '#f3f4f6', fontSize: '10px', fontFamily: 'JetBrains Mono', textTransform: 'uppercase', boxShadow: '0 8px 30px rgba(0,0,0,0.5)' }}
            itemStyle={{ color: '#d1d5db' }}
          />
          <Legend wrapperStyle={{ fontSize: '10px', fontFamily: 'JetBrains Mono', paddingTop: '10px', display: 'none' }} />
          
          <Area 
            type="monotone" 
            dataKey="close" 
            name="Harga Penutupan"
            stroke="#10b981" 
            strokeWidth={2}
            fillOpacity={1} 
            fill="url(#colorClose)" 
            isAnimationActive={false}
          />
          <Line 
            type="monotone" 
            dataKey="emaFast" 
            name="EMA 50 (Fast)"
            stroke="#3b82f6" 
            strokeWidth={2} 
            dot={false}
            isAnimationActive={false}
            strokeDasharray="4 4"
          />
          <Line 
            type="monotone" 
            dataKey="emaSlow" 
            name="EMA 200 (Slow)"
            stroke="#a855f7" 
            strokeWidth={2} 
            dot={false}
            isAnimationActive={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
