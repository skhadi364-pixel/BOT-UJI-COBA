import { useEffect, useRef } from 'react';
import { cn } from '../lib/utils';

interface TerminalViewerProps {
  logs: string[];
  className?: string;
}

export function TerminalViewer({ logs, className }: TerminalViewerProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  return (
    <div className={cn("overflow-hidden flex flex-col font-mono text-[10px] leading-relaxed", className)}>
      <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest block mb-2 px-5 pt-5">Live Execution Log</span>
      <div className="overflow-y-auto flex-1 px-5 pb-5 scrollbar-hide space-y-0.5 opacity-80">
        {logs.map((log, i) => {
          // Syntax highlighting emulation
          const isError = log.includes('Gagal') || log.includes('Error');
          const isSuccess = log.includes('Berhasil') || log.includes('sukses');
          const isHeader = log.includes('===');
          
          return (
            <div 
              key={i} 
              className={cn(
                "flex transition-opacity",
                isError ? "text-rose-400" : isSuccess ? "text-emerald-400" : isHeader ? "text-white font-bold" : "text-gray-300"
              )}
            >
              <span className="text-gray-600 mr-2 select-none">{'>'}</span>
              <span 
                className={cn("whitespace-pre-wrap break-all")}
                dangerouslySetInnerHTML={{ __html: log.replace(/\n/g, '<br/>') }} 
              />
            </div>
          );
        })}
        <div ref={bottomRef} className="h-2" />
      </div>
    </div>
  );
}
