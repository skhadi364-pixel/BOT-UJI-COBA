import { useState, useEffect } from 'react';
import { SquareTerminal, X, Info, Zap, UserSquare2, Settings } from 'lucide-react';
import { cn } from '../lib/utils';

export interface BotConfig {
  account: string;
  password?: string;
  server: string;
  symbol: string;
  timeframe: string;
  initialCapital: string;
  targetProfit: string;
  tradingMode: 'AUTO' | 'MANUAL';
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  config: BotConfig;
  onChange: (config: BotConfig) => void;
  onStart: () => void;
  isRunning: boolean;
}

export function BotControlPanel({ isOpen, onClose, config, onChange, onStart, isRunning }: Props) {
  const [localConfig, setLocalConfig] = useState<BotConfig>(config);

  useEffect(() => {
    if (isOpen) {
      setLocalConfig(config);
    }
  }, [isOpen, config]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" style={{ backgroundColor: '#e7f204' }}>
      <div className="bg-[#0A0A0A] border border-white/[0.05] p-8 flex flex-col relative overflow-hidden w-full max-w-xl shadow-2xl rounded-3xl" style={{ backgroundColor: '#1bb8b1', borderColor: '#2af509' }}>
        <div className="absolute top-0 right-0 p-16 opacity-5 pointer-events-none">
          <Settings className="w-64 h-64 text-white animate-spin-slow duration-[3000ms]" />
        </div>
        <div className="flex justify-between items-center mb-8 pb-6 border-b border-white/[0.05] relative z-10">
          <h2 className="text-xs uppercase text-gray-500 flex items-center font-mono">
            <SquareTerminal className="w-5 h-5 mr-3 text-emerald-500" />
            <span className="text-white font-bold tracking-widest text-sm">ENGINE CONFIGURATION</span>
          </h2>
          <button onClick={onClose} className="text-rose-500 hover:text-rose-400 transition-colors bg-rose-500/10 p-2 rounded-full hover:bg-rose-500/20">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex bg-blue-500/10 border border-blue-500/20 p-4 rounded-2xl mb-8 items-start gap-4 relative z-10 shadow-inner">
           <Info className="w-5 h-5 text-blue-400 mt-0.5 shrink-0" />
           <p className="text-[11px] text-blue-300/80 leading-relaxed uppercase tracking-widest font-mono" style={{ color: '#000000', marginTop: '41px' }}>
             Settings can only be modified when the engine is not actively executing trades or analyzing data settings.
           </p>
        </div>

        <div className="space-y-6 relative z-10">
          <div className="grid grid-cols-2 gap-6">
            <div>
              <label className="block text-[10px] font-bold text-gray-500 mb-2 uppercase tracking-widest font-mono" style={{ marginTop: '-25px', color: '#000000' }}>Account ID</label>
              <input 
                type="text" 
                value={localConfig.account}
                onChange={e => setLocalConfig({...localConfig, account: e.target.value})}
                className="w-full bg-[#0D0D12] border border-white/[0.05] rounded-xl px-5 py-4 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all font-mono shadow-inner"
                disabled={isRunning}
              />
            </div>
            <div style={{ marginTop: '-25px' }}>
              <label className="block text-[10px] font-bold text-gray-500 mb-2 uppercase tracking-widest font-mono" style={{ color: '#000000' }}>Password</label>
              <input 
                type="password" 
                value={localConfig.password || ''}
                onChange={e => setLocalConfig({...localConfig, password: e.target.value})}
                className="w-full bg-[#0D0D12] border border-white/[0.05] rounded-xl px-5 py-4 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all font-mono shadow-inner"
                disabled={isRunning}
              />
            </div>
          </div>
          
          <div style={{ marginTop: '-18px' }}>
            <label className="block text-[10px] font-bold text-gray-500 mb-2 uppercase tracking-widest font-mono" style={{ color: '#030303' }}>Server / Broker</label>
            <input 
              type="text" 
              value={localConfig.server}
              onChange={e => setLocalConfig({...localConfig, server: e.target.value})}
              className="w-full bg-[#0D0D12] border border-white/[0.05] rounded-xl px-5 py-4 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all font-mono shadow-inner"
              disabled={isRunning}
            />
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div style={{ marginTop: '-18px' }}>
              <label className="block text-[10px] font-bold text-gray-500 mb-2 uppercase tracking-widest font-mono" style={{ color: '#0a0a0a' }}>Symbol</label>
              <input 
                type="text" 
                value={localConfig.symbol}
                onChange={e => setLocalConfig({...localConfig, symbol: e.target.value})}
                className="w-full bg-[#0D0D12] border border-white/[0.05] rounded-xl px-5 py-4 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all font-mono uppercase shadow-inner"
                disabled={isRunning}
              />
            </div>
            <div style={{ marginTop: '-18px' }}>
              <label className="block text-[10px] font-bold text-gray-500 mb-2 uppercase tracking-widest font-mono" style={{ color: '#010101' }}>Timeframe</label>
              <select 
                value={localConfig.timeframe}
                onChange={e => setLocalConfig({...localConfig, timeframe: e.target.value})}
                className="w-full bg-[#0D0D12] border border-white/[0.05] rounded-xl px-5 py-4 text-sm text-white focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all appearance-none cursor-pointer font-mono shadow-inner"
                disabled={isRunning}
              >
                <option value="1">M1</option>
                <option value="5">M5</option>
                <option value="15">M15</option>
                <option value="60">H1</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6 mt-6 bg-[#0D0D12] p-6 rounded-2xl border border-white/[0.05] shadow-inner" style={{ marginTop: '-19px' }}>
            <div>
              <label className="block text-[10px] font-bold text-gray-500 mb-2 uppercase tracking-widest font-mono" style={{ color: '#f9f9f9' }}>Initial Capital (IDR)</label>
              <input 
                type="number" 
                value={localConfig.initialCapital}
                onChange={e => setLocalConfig({...localConfig, initialCapital: e.target.value})}
                className="w-full bg-[#0A0A0A] border border-white/[0.05] rounded-xl px-4 py-4 text-sm text-emerald-400 placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all font-mono font-bold"
                disabled={isRunning}
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-gray-500 mb-2 uppercase tracking-widest font-mono" style={{ color: '#ffffff' }}>Target Profit (IDR)</label>
              <input 
                type="number" 
                value={localConfig.targetProfit}
                onChange={e => setLocalConfig({...localConfig, targetProfit: e.target.value})}
                className="w-full bg-[#0A0A0A] border border-white/[0.05] rounded-xl px-4 py-4 text-sm text-emerald-400 placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all font-mono font-bold"
                disabled={isRunning}
              />
            </div>
          </div>

          <div className="bg-[#0D0D12] p-6 rounded-2xl border border-white/[0.05] shadow-inner mt-6" style={{ marginTop: '-20px' }}>
            <label className="block text-[10px] font-bold text-gray-500 mb-4 uppercase tracking-widest font-mono" style={{ textAlign: 'center', color: '#f8fcff' }}>Execution Mode</label>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => {
                  const newConfig = { ...localConfig, tradingMode: 'AUTO' as const };
                  setLocalConfig(newConfig);
                  onChange(newConfig);
                  onClose();
                  if (!isRunning) {
                    setTimeout(() => onStart(), 100);
                  }
                }}
                disabled={isRunning}
                className={cn(
                  "py-4 px-4 flex items-center justify-center space-x-3 text-xs font-bold tracking-widest uppercase transition-all border rounded-xl",
                  localConfig.tradingMode === 'AUTO' 
                    ? "bg-emerald-500/10 border-emerald-500/50 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.2)]" 
                    : "bg-[#0A0A0A] border-white/[0.05] text-gray-500 hover:text-gray-300 hover:border-white/10"
                )}
                style={{ backgroundColor: '#14f903' }}
              >
                <Zap className={cn("w-5 h-5", localConfig.tradingMode === 'AUTO' ? "text-emerald-400 fill-emerald-500/20" : "")} />
                <span style={{ color: '#000000', paddingTop: '0px', paddingBottom: '0px', paddingRight: '17px' }}>System Auto</span>
              </button>
              <button
                onClick={() => {
                  window.location.reload();
                }}
                className={cn(
                  "py-4 px-4 flex items-center justify-center space-x-3 text-xs font-bold tracking-widest uppercase transition-all border rounded-xl",
                  localConfig.tradingMode === 'MANUAL' 
                    ? "bg-blue-500/10 border-blue-500/50 text-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.2)]" 
                    : "bg-[#0A0A0A] border-white/[0.05] text-gray-500 hover:text-gray-300 hover:border-white/10"
                )}
                style={{ backgroundColor: '#f40505' }}
              >
                <UserSquare2 className={cn("w-5 h-5", localConfig.tradingMode === 'MANUAL' ? "text-blue-400" : "")} />
                <span style={{ color: '#fff8f8', textAlign: 'center', marginTop: '0px', paddingTop: '0px', marginBottom: '-3px', marginRight: '0px', paddingLeft: '0px', paddingBottom: '0px', paddingRight: '16px' }}>Manual User</span>
              </button>
            </div>
          </div>

          <div className="flex justify-end space-x-4 pt-6 border-t border-white/[0.05] mt-8">
            <button 
              onClick={onClose}
              className="px-8 py-4 rounded-xl text-xs font-bold tracking-widest text-rose-400 uppercase bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 hover:text-rose-300 transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={() => {
                onChange(localConfig);
                onClose();
                if (localConfig.tradingMode === 'MANUAL') {
                  window.location.reload();
                } else if (!isRunning) {
                  onStart();
                }
              }}
              disabled={isRunning}
              className={cn(
                "px-10 py-4 rounded-xl text-xs font-bold tracking-widest uppercase transition-all flex items-center justify-center border",
                isRunning 
                  ? "bg-[#0D0D12] text-gray-500 border-white/[0.05] cursor-not-allowed" 
                  : "bg-emerald-500/10 border-emerald-500/50 hover:bg-emerald-500/20 text-emerald-400 hover:shadow-[0_0_20px_rgba(16,185,129,0.3)]"
              )}
            >
              Apply & Start
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
